<h1>search page</h1>
<div class="article-container">
<div class="product-card">
    <div class="product-image">
    <div class="product-info">
<?php
	include 'header.php';

	if (isset($_POST["submit"])) {
		$search = mysqli_real_escape_string($db, $_POST['search']);
		$sql = "SELECT * FROM images WHERE title LIKE '%$search%' OR name LIKE '%$search%' OR phone LIKE '%$search%' OR image LIKE '%$search%'";
		$result = mysqli_query($db, $sql);
		$queryResult = mysqli_num_rows($result);
		if ($queryResult > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
					$title="";
	        $name="Brand:";
	        $phone="Phone:";
	        $des="Description:";
	        $space=" ";
	  			echo "<img src='uploads/".$row['image']."' >";
	        echo "<font size='4' face='Times New Roman'>";
	        echo  "<p>".$title.$space.$row['title']."</p>";
	        echo "<p>".$name.$space.$row['name']."</p>";
	        echo "<p>".$phone.$space.$row['phone']."</p>";
	        echo "<p>".$des.$space.$row['image_text']."</p>";


		}
		}
	} else {
		echo "There are no results!";
	}
?>
</div>
