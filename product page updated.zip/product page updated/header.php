<?php
	include 'index.php';
?>
<!DOCTYPE html>
<html>
<head>
	<style>
	body {
			background-color: white;
		}

		.article-container {
			width: 800px;
			background-color: #fff;
			padding: 30px;
		  margin: auto;
		  width: 1000px 10px;
		  height: auto;
		  margin: 20px auto;
		  border: 2px solid #39F541;
		}

		.article-box {
			width: 50%;
			padding-bottom: -20px;
		}

		input {
			padding: 0px 20px;
			width: 300px;
			height: 40px;
			font-size: 22px;
		  margin-right: : auto;
		}

		button {
			width: 100px;
			height: 44px;
			font-size: 22px;
		}
		img{
		  float: auto;
		  margin: -10px 10px;
		  width: 650px;
		  height: 480px;
		  padding: 30px;
		}
		p {
		    font-size: 15pt;
		}
		#img_div:after{
		  content: "";
		  display: block;
		  clear: both;
		}
		#content{
		  width: 1000px 10px;
		  height: 900px;
		  margin: 20px auto;
		  border: 2px solid #39F541;
			box-shadow: 5px 5px 5px #888888;
		}

	</style>
	<title></title>

</head>
<body>
</body>
</html>
