<html>
<head>
  <style>
  body {
    background-image: url("pick.png");
}
.button {
      background-color:#11C6F3;
      border: none;
      color: white;
      padding: 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      height:auto;
      width:auto;
      font-size: 15px;
      margin: 0px -700px;
      cursor: pointer;
      border-radius: 8px;

  }
input[type=text] {
    width: 200px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px;
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
     margin:-500px 700px;
     background-color: #A9A9A9;
     border: 2px solid #FFF301;
}



}
body {
	background-color: white;
}
img {
   position:absolute; top:-20px; left:-50px;
}

  </style>
</head>
<body>
  <?php
  	include 'index.php';
  ?>
<img src="logo1.png" width="270" height="150"  />
  <form action="search.php" method="POST">
  	<input  type="text" name="search" placeholder="Search">
  	<button class="button" type="submit" name="submit">Search</button>
  </form>
</body>
  </html>
</div>
</body>
</html>
