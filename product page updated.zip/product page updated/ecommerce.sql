-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2018 at 02:03 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(50) NOT NULL,
  `username` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `confirmPassword` varchar(256) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `username`, `email`, `password`, `confirmPassword`, `phone`, `image`) VALUES
(1, 'dhruv887', 'dprobo5@gmail.com', '$2y$10$TFC3OBX45uKGK/GbGfUn3uN5XEGHkp2s6ufhT5kjQ5IDPLcWPyn1q', '$2y$10$h0.7z3jz/I.GV2aegnoHN.hVU0fLaf7vxjTWY5HbVwzt9zrXbmj3q', '9821150892', ''),
(2, 'dhruv887', 'dprobo5@gmail.com', '$2y$10$iSKsagedpTeJUsXEMw1pjez3lDlcNQd8QYRBYEKY0xqULWOgD5ACy', '$2y$10$vUiodQXPVOOClFQBzjoHOOItQXUr1M3CErZe4qcni28AIthwEc61.', '9821150892', ''),
(3, 'dd', 'dd@gmail.com', '$2y$10$AZXXa1tX4xYJzhjrfl66ke5GweyeI3IN5vFhxNDzW2xkr/er35adK', '$2y$10$dW2cs8koOafr1lMUrGcOIe7jvzQ7xjzCi1mdKdNk8IDvuXLD5TDCy', '9821150892', ''),
(4, 'ss', '9s@gmail.com', '$2y$10$51s7Fxhvb139gpiiPsH6w.A6k7nkUm3BgtiYCEz7app8tddNIA1AO', '$2y$10$6Jng9uOFgOPqKvgHJMLX8ekcArwqa9JceIo0NLcgNhdZQzOzSrSui', '9821150892', ''),
(5, 'ss', '9s@gmail.com', '$2y$10$2ldOi9E5OWcswGHX1WFpjuG8Pfo9FMonjjjMkWaYqd5srJeuzfHha', '$2y$10$QSDe3YoByxiFk8J9s/FNF.IBcA3e.dx/s5oaufL0NGnkGkIJfJA1a', '9821150892', ''),
(6, 'dhruv887', 'dprobo5@gmail.com', '$2y$10$nr9nBKn8XJQnqN/kGlG/duqmh/gQ6.kRpJrbBlav/rfp1wrhfWcUK', '$2y$10$KBwEomNMe8yM3mLwjGuWHOSr500AcMH1XeRPqSP9nJyawefhJecwu', '9821150892', ''),
(7, 'dd', 'dd@gmail.com', '$2y$10$UwmNEfXiuCGnzhyKddgoBubngSWLsSphwPaxghTKL/HPbeL0SUQrK', '$2y$10$1YjaMURIYviXLsHv83uuIOOcOVNeOXCkgxA5YSzERELnE7sQUOvXu', '35545454545', ''),
(8, 'ddd', 'dd@gmail.com', '$2y$10$SLveeCrAqj9rsW0JYlRIUewClE53Eg867KQkFqvRdGTnKrY2Jk/62', '$2y$10$LCPEubcxMNPr2hIR9lGReeLgZX5K5pBeY6W9xB3MkRHVKIffjSh9S', '35445', ''),
(9, 'ddd', 'dd@gmail.com', '$2y$10$KVRE0sTTE.6YCWcKtyXLTuIw8SHRB/Unc1LuG2DuC3r8jvHsSYy16', '$2y$10$GL3wWZTE3.wFz4ftnASvteNpzyb/Tz2V4eutWvbBEpSjP9CMXbbau', '35445', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `adtitle` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `adtitle`, `description`, `image`) VALUES
(1, 'tttt', '', '039-300x300.png'),
(2, 'tttt', '', '039-300x300.png'),
(3, 'tttt', '', '039-300x300.png'),
(4, 'd', 'df', '284131185_029.png');

-- --------------------------------------------------------

--
-- Table structure for table `product_overview`
--

CREATE TABLE `product_overview` (
  `category` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_overview`
--

INSERT INTO `product_overview` (`category`, `type`, `brand`, `image`) VALUES
('electronic', 'mobile', 'samsung', ''),
('electronic', 'smartphones', 'samsung', ''),
('electronic', 'tablets', 'samsung', ''),
('clothing', 'jeans', 'levi\'s', ''),
('footwear', 'sneakers', 'nike', ''),
('medicines', 'painkiller', 'manforce', '');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `id` int(200) NOT NULL,
  `First` varchar(200) NOT NULL,
  `Last` varchar(200) NOT NULL,
  `Company` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Phone` varchar(200) NOT NULL,
  `Address1` varchar(200) NOT NULL,
  `Address2` varchar(200) NOT NULL,
  `Pin` varchar(200) NOT NULL,
  `Pan` varchar(200) NOT NULL,
  `Password1` varchar(200) NOT NULL,
  `Password2` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id`, `First`, `Last`, `Company`, `Email`, `Phone`, `Address1`, `Address2`, `Pin`, `Pan`, `Password1`, `Password2`) VALUES
(22, 'dd', 'dd', 'dd', 'dd', 'dd', 'dd', 'ddd', 'dd', 'dd', '1aabac6d068eef6a7bad3fdf50a05cc8', '1aabac6d068eef6a7bad3fdf50a05cc8');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
