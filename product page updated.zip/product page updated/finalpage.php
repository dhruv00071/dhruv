<html>
<head>

  <style>
  img {
     position:absolute; top:-20px; left:-50px;
  }
  body {
    background-image: url("pick.png");
}
.button {
    background-color:red; /* Green */
    border: none;
    color: white;
    padding: 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    height:100px;
    width: 170px;
    font-size: 25px;
    margin: -70px -90px;
    cursor: pointer;

}
.button3 {border-radius: 8px;}
.wrapper {
    text-align: center;
}

.button4 {
    position: absolute;
    top: 500px;
}
p {
    font-size: 40pt;
    line-height: -11100px;
    padding: 250px 0;

}
body {
    background-color: rgba(238, 238, 238,0.4)  ;
}
</style>
<style>

  </style>
</head>
<body>
    <img src="logo1.png" width="270" height="150"  />

  <p align="center">Your ad will be uploaded whithin 24 hrs</p>
  <div class="wrapper">
  <button  class="button4 button button3">Continue</button>
  </div>
</body>
</html>
