  <?php
	$db = mysqli_connect("localhost", "root", "", "image_upload");
	$msg = "";

	if (isset($_POST['upload'])) {
		$target = "uploads/".basename($_FILES['image']['name']);


		$image = $_FILES['image']['name'];
		$image_text = mysqli_real_escape_string($db, $_POST['image_text']);
    $title =  mysqli_real_escape_string ($db,$_POST['title']);
    $name =  mysqli_real_escape_string ($db,$_POST['name']);
		$phone =  mysqli_real_escape_string ($db,$_POST['phone']);
		$siz =  mysqli_real_escape_string ($db,$_POST['siz']);
		$sql = "INSERT INTO images (image, image_text,title,name,phone,siz) VALUES ('$image', '$image_text','$title','$name','$phone','$siz')";
		mysqli_query($db, $sql);

		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			header("Location: finalpage.php");
			        exit();
		}else{
			$msg = "Failed to upload image";
		}
	}

	$result = mysqli_query($db, "SELECT * FROM images");

?>
