<!DOCTYPE html>
<html>
<head>
	<title>Image Upload</title>
	<style type="text/css">
	body {
    background-image: url("pick.png");
}
		form{
			width: 50%;
			margin: 20px 30px;
		}
		form div{
			margin-top: 5px;
		}
		#img_div{
			width: 600px;
			padding: 5px;
			margin: 15px auto;
			border: 1px solid #39F541;
			box-shadow: 5px 5px 5px #888888;
		}
		#img_div:after{
			content: "";
			display: block;
			clear: both;
		}
		img{
			float: left;
			margin: 5px;
			width: 320px;
			height: 180px;
		}
		.button3 {border-radius: 4px;}
		.button {
		    background-color:#11C6F3;
		    border: none;
		    color: white;
		    padding: 20px;
		    text-align: center;
		    text-decoration: none;
		    display: inline-block;
		    height:auto;
		    width:auto;
		    font-size: 15px;
		    margin: 15px 250px;
		    cursor: pointer;

		}
		input[type=text] {
	    width: 500px;
	    padding: 12px 20px;
	    margin: 8px 250px;
	    box-sizing: border-box;
	    border: 2px solid #FFF301;
	    background-color: ;
	    color: black;
	}
	textarea{
	  width: 500px;
	  padding: 12px 20px;
	  margin: 8px 250px;
	  box-sizing: border-box;
	 border: 2px solid #FFF301;
	  background-color:;
	  color: black;
	}
	input[type=file] {
	    margin: 10px 250px;
	}
	textarea::placeholder {
	  color: black;
	  font-size: 15px;
	}
  input::placeholder{
    color: black;
	  font-size: 15px;
  }
	input[class=size]{
		width: 90px;
		padding: 12px 20px;
		margin: 8px 250px;
		box-sizing: border-box;
		border: 2px solid #FFF301;
		background-color:;
		color: black;
	}
	input[class=phone]{
		width: 200px;
		padding: 12px 20px;
		margin: 8px 250px;
		box-sizing: border-box;
		border: 2px solid #FFF301;
		background-color: #white;
		color: white;
	}
	input[class=brand]{
		width: 150px;
		padding: 12px 20px;
		margin: 8px 250px;
		box-sizing: border-box;
		border: 2px solid #FFF301;
		background-color: #white;
		color: black;
	}
	img {
	   position:absolute; top:-20px; left:-50px;
	}
	</style>
</head>
<body>
	  <img src="logo1.png" width="270" height="150"  />
<div id="content">

	<form method="POST" action="index.php" enctype="multipart/form-data">
		<input  type="text" name="title" placeholder="Ad Title" required><br></br>
<input class="brand"  type="text" name="name" placeholder="Brand" required><br></br>
<input  class="phone" type="text" name="phone" placeholder="Phone" required><br></br>
<input  class="size" type="text" name="siz" placeholder="size" required><br></br>
	<textarea id="text" cols="40" rows="4" name="image_text" placeholder="Description...."  required></textarea>
		<input type="hidden" name="size" value="1000000">
		<div>
			<input type="file" name="image">
		</div>
		<div>

		</div>
		<div>
			<button class="button3 button" type="submit" name="upload">Upload</button>
		</div>
	</form>
</div>
</body>
</html>
