<?php
include 'index.php';
 ?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
.gg {
   position:absolute; top:-20px; left:-90px;
}
body {
  background-image: url("pick.png");
}
  #img_div{
    width: 700px;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid #39F541;
    box-shadow: 5px 5px 5px #888888;
  }
  #img_div:after{
    content: "";
    display: block;
    clear: both;
  }
  img{
    float: left;
    margin: 5px;
    width: 320px;
    height: 180px;
  }
    </style>
</head>
<body>
    <img class="gg" src="logo1.png" width="270" height="150"  />
      <div id="content">
  <?php

  	while ($row = mysqli_fetch_array($result)) {
  		echo "<div id='img_div'>";
        $title="Title:";
        $name="Brand:";
        $phone="Phone:";
        $des="Description:";
        $size="Size:";
        $space=" ";
  			echo "<img src='uploads/".$row['image']."' >";
        echo "<font size='4' face='Times New Roman'>";
        echo  "<p>".$title.$space.$row['title']."</p>";
        echo "<p>".$name.$space.$row['name']."</p>";
        echo "<p>".$size.$space.$row['siz']."</p>";
        echo "<p>".$phone.$space.$row['phone']."</p>";
        echo "<p>".$des.$space.$row['image_text']."</p>";

  		echo "</div>";
  	}
  ?>

</body>
</html>
